export const defaultSettings = {
 name:'캐릭터 파일',subtitle:'CHARACTER FILES',headline:'캐릭터 보관함',
 intro:'시리즈별로 정리한 인물 프로필입니다. 필요한 설정을 복사해 사용하세요.',author:'캐릭터 아카이브'
};
export const GENRES={daily:'일상',fantasy:'판타지',urban:'현판',special:'특별'};
export class HttpError extends Error { constructor(status,message){super(message);this.status=status;} }
const fail=(m)=>{throw new HttpError(400,m)};
function text(v,key,max,required=false){const s=v?.[key]??'';if(typeof s!=='string'||s.length>max||(required&&!s.trim()))fail(`${key} 항목을 확인해 주세요. (최대 ${max}자)`);return s;}
export function id(v){if(typeof v!=='string'||!/^[a-zA-Z0-9_-]{1,80}$/.test(v))fail('ID는 영문·숫자·-·_로 80자 이내여야 합니다.');return v;}
function order(v){if(v===undefined)return 0;if(!Number.isInteger(v)||Math.abs(v)>10000)fail('표시 순서를 확인해 주세요.');return v;}
export function genreInput(v){if(v===undefined)return 'special';if(!Object.hasOwn(GENRES,v))fail('분류는 일상·판타지·현판·특별 중 선택해 주세요.');return v;}
export function seriesInput(v){return {id:id(v?.id),name:text(v,'name',80,true).trim(),description:text(v,'description',500),genre:genreInput(v.genre),theme:['wine','forest','navy','umber','violet','blue','mint','rose','amber','slate'].includes(v.theme)?v.theme:'wine',sortOrder:order(v.sortOrder),revision:Number.isInteger(v.revision)?v.revision:0};}
export function imageURL(v){if(!v)return '';if(typeof v!=='string'||v.length>2048)fail('이미지 주소를 확인해 주세요.');try{const u=new URL(v,'https://archive.invalid');if(/^\/api\/images\/[a-zA-Z0-9_-]{1,80}$/.test(v))return v;if(v.startsWith('/portraits/')&&!v.includes('..')&&!v.includes('\\'))return v;if(v.startsWith('https://')&&u.protocol==='https:'&&!u.username&&!u.password)return u.href;}catch{}fail('이미지는 HTTPS 주소 또는 /portraits/ 경로를 사용해 주세요.');}
export function characterInput(v){
  if(!v||typeof v!=='object')fail('캐릭터 데이터를 확인해 주세요.');
  if(v.category&&v.category!=='캐릭터')fail('캐릭터만 등록할 수 있습니다.');
  if(!Array.isArray(v.sections)||!v.sections.length||v.sections.length>20)fail('설정 블록은 1~20개까지 등록할 수 있습니다.');
  if(v.sections.some(s=>!s||typeof s!=='object'||Array.isArray(s)))fail('설정 블록 형식을 확인해 주세요.');
  const sections=v.sections.map((s,i)=>({id:id(s.id||`section-${i}`),title:text(s,'title',100,true),content:text(s,'content',300000),language:['text','markdown','json','html','jsx'].includes(s.language)?s.language:'text'}));
  if(sections.reduce((n,s)=>n+s.content.length,0)>300000)fail('캐릭터 설정은 합계 30만 자 이내여야 합니다.');
  if(new Set(sections.map(s=>s.id)).size!==sections.length)fail('설정 블록 ID가 중복되었습니다.');
  if(!Array.isArray(v.tags??[])||(v.tags??[]).length>12||(v.tags??[]).some(t=>typeof t!=='string'||!t.trim()||t.length>40))fail('태그는 40자 이내, 최대 12개까지 입력해 주세요.');
  if(v.status&&!['draft','published'].includes(v.status))fail('공개 상태를 확인해 주세요.');
  const status=v.status||'draft';if(status==='published'&&!sections.some(s=>s.content.trim()))fail('공개하려면 캐릭터 설정을 입력해 주세요.');
  return {id:id(v.id),seriesId:id(v.seriesId),title:text(v,'title',120,true).trim(),summary:text(v,'summary',500),category:'캐릭터',profile:{role:text(v.profile,'role',80),species:text(v.profile,'species',80),age:text(v.profile,'age',40),gender:text(v.profile,'gender',40)},tags:(v.tags??[]).map(t=>t.trim()),sections,version:text(v,'version',40)||'1.0',status,imageUrl:imageURL(v.imageUrl),pinned:v.pinned===true,sortOrder:order(v.sortOrder),revision:Number.isInteger(v.revision)?v.revision:0};
}
export function settingsInput(v){return {name:text(v,'name',30,true),subtitle:text(v,'subtitle',60),headline:text(v,'headline',100,true),intro:text(v,'intro',300),author:text(v,'author',60)};}
export function importInput(v){if(![1,2].includes(v?.schemaVersion)||!Array.isArray(v.series))fail('schemaVersion: 1 또는 2 형식의 JSON 파일을 사용해 주세요.');const cc=v.characters??v.workshops;if(!Array.isArray(cc)||v.series.length>100||cc.length>200)fail('한 번에 시리즈 100개, 캐릭터 200개까지 가져올 수 있습니다.');const s=v.series.map(seriesInput),c=cc.map(characterInput);if(new Set(s.map(x=>x.id)).size!==s.length||new Set(c.map(x=>x.id)).size!==c.length)fail('가져오는 파일에 중복 ID가 있습니다.');return {series:s,characters:c};}
export const rawText=c=>c.sections.map(s=>s.content).join('\n\n');
