import {HttpError} from './model.js';
const enc=new TextEncoder();
export const hex=b=>Array.from(new Uint8Array(b),n=>n.toString(16).padStart(2,'0')).join('');
export const sha=async s=>hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));
const random=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
export const cookieName=request=>new URL(request.url).protocol==='https:'?'__Host-seoga_admin':'seoga_local_admin';
export function cookie(request,value,maxAge){return `${cookieName(request)}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
export function sameOrigin(request,json=true){if(request.headers.get('origin')!==new URL(request.url).origin||request.headers.get('sec-fetch-site')==='cross-site')throw new HttpError(403,'현재 사이트에서 직접 요청해 주세요.');if(json&&!request.headers.get('content-type')?.startsWith('application/json'))throw new HttpError(415,'JSON 요청이 필요합니다.');}
export function configured(env){return typeof env.ADMIN_PASSWORD_HASH==='string'&&/^pbkdf2:100000:[a-f0-9]{32}:[a-f0-9]{64}$/.test(env.ADMIN_PASSWORD_HASH);}
export async function session(request,env){
 if(!configured(env))return null;
 const name=cookieName(request);const token=(request.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1);
 if(!token||!/^\w{64}$/.test(token))return null;
 const hash=await sha(token),now=Date.now();
 const s=await env.DB.prepare('SELECT * FROM admin_sessions WHERE token_hash=? AND expires_at>?').bind(hash,now).first();
 if(!s||s.password_version!==await sha(env.ADMIN_PASSWORD_HASH))return null;
 return s;
}
export async function requireSession(request,env,write=false){const s=await session(request,env);if(!s)throw new HttpError(401,'관리자 로그인이 필요합니다.');if(write){sameOrigin(request);if(request.headers.get('x-seoga-csrf')!==s.csrf)throw new HttpError(403,'로그인 상태를 새로 확인해 주세요.');}return s;}
export async function readJSON(request,max=2200000){
 if(Number(request.headers.get('content-length')||0)>max)throw new HttpError(413,'요청이 너무 큽니다. JSON은 2MB 이내로 준비해 주세요.');
 const reader=request.body?.getReader();if(!reader)throw new HttpError(400,'요청 내용이 없습니다.');
 let n=0;const chunks=[];while(true){const {done,value}=await reader.read();if(done)break;n+=value.length;if(n>max){await reader.cancel();throw new HttpError(413,'요청 크기 제한을 초과했습니다.');}chunks.push(value);}
 const bytes=new Uint8Array(n);let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}
 try{const parsed=JSON.parse(new TextDecoder().decode(bytes));if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('object required');return parsed;}catch{throw new HttpError(400,'JSON 객체 형식을 확인해 주세요.');}
}
export async function login(request,env,ctx){
 sameOrigin(request);
 if(!configured(env))throw new HttpError(503,'관리자 비밀번호가 아직 설정되지 않았습니다. 배포 안내의 비밀번호 설정을 완료해 주세요.');
 const url=new URL(request.url);if(url.protocol!=='https:'&&!['127.0.0.1','localhost','[::1]'].includes(url.hostname))throw new HttpError(403,'HTTPS 연결에서 로그인해 주세요.');
 const {password}=await readJSON(request,4096);
 if(typeof password!=='string'||password.length>256)throw new HttpError(400,'비밀번호를 확인해 주세요.');
 const now=Date.now(),window=Math.floor(now/900000),ip=request.headers.get('CF-Connecting-IP')||'local';
 const key=await sha(env.ADMIN_PASSWORD_HASH+'|'+ip+'|'+window),expires=(window+1)*900000;
 const row=await env.DB.prepare('INSERT INTO login_attempts(key,attempts,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=attempts+1 RETURNING attempts').bind(key,expires).first();
 if(row.attempts===1)ctx.waitUntil(env.DB.prepare('DELETE FROM login_attempts WHERE expires_at<?').bind(now).run());
 if(row.attempts>5)throw new HttpError(429,'로그인 시도가 많습니다. 15분 후 다시 시도해 주세요.');
 const [,iterations,salt,expected]=env.ADMIN_PASSWORD_HASH.split(':');
 const material=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
 const derived=hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',iterations:Number(iterations),salt:Uint8Array.from(salt.match(/../g),x=>parseInt(x,16))},material,256));
 let diff=derived.length^expected.length;for(let i=0;i<expected.length;i++)diff|=derived.charCodeAt(i)^expected.charCodeAt(i);
 if(diff!==0)throw new HttpError(401,'비밀번호가 일치하지 않습니다.');
 const token=random(),csrf=random(),tokenHash=await sha(token);
 await env.DB.batch([
  env.DB.prepare('DELETE FROM login_attempts WHERE key=?').bind(key),
  env.DB.prepare('INSERT INTO admin_sessions(token_hash,csrf,expires_at,password_version) VALUES (?,?,?,?)').bind(tokenHash,csrf,now+28800000,await sha(env.ADMIN_PASSWORD_HASH)),
 ]);
 ctx.waitUntil(env.DB.batch([env.DB.prepare('DELETE FROM admin_sessions WHERE expires_at<?').bind(now),env.DB.prepare('DELETE FROM login_attempts WHERE expires_at<?').bind(now)]));
 return {csrf,cookie:cookie(request,token,28800)};
}
