import {HttpError,id} from './model.js';
import {requireSession,sameOrigin,session} from './auth.js';
export const MAX_IMAGE_BYTES=1000000;
export function imageType(bytes){
 const b=new Uint8Array(bytes);if(b.length<12)throw new HttpError(400,'JPG, PNG, WebP 이미지 파일을 선택해 주세요.');
 if(b[0]===255&&b[1]===216&&b[2]===255)return 'image/jpeg';
 if([137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v))return 'image/png';
 if(new TextDecoder().decode(b.slice(0,4))==='RIFF'&&new TextDecoder().decode(b.slice(8,12))==='WEBP')return 'image/webp';
 throw new HttpError(400,'JPG, PNG, WebP 이미지 파일만 등록할 수 있습니다.');
}
export async function uploadImage(request,env,ctx){
 const s=await requireSession(request,env);sameOrigin(request,false);
 if(request.headers.get('x-seoga-csrf')!==s.csrf)throw new HttpError(403,'로그인 상태를 다시 확인해 주세요.');
 if(Number(request.headers.get('content-length')||0)>MAX_IMAGE_BYTES)throw new HttpError(413,'사진은 1MB 이하로 저장할 수 있습니다.');
 const reader=request.body?.getReader();if(!reader)throw new HttpError(400,'사진 파일이 없습니다.');
 let length=0;const chunks=[];while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>MAX_IMAGE_BYTES){await reader.cancel();throw new HttpError(413,'사진은 1MB 이하로 저장할 수 있습니다.');}chunks.push(value);}
 const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 const mime=imageType(bytes),key=crypto.randomUUID(),now=new Date().toISOString();
 await env.DB.prepare('INSERT INTO archive_images(id,content_type,bytes,created_at) VALUES (?,?,?,?)').bind(key,mime,bytes.buffer,now).run();
 ctx.waitUntil(env.DB.prepare("DELETE FROM archive_images WHERE created_at<? AND NOT EXISTS (SELECT 1 FROM archive_characters WHERE json_extract(data,'$.imageUrl')='/api/images/'||archive_images.id)").bind(new Date(Date.now()-86400000).toISOString()).run());
 return {url:'/api/images/'+key};
}
export async function serveImage(request,env,key){
 id(key);const visible=await env.DB.prepare("SELECT id FROM archive_characters WHERE status='published' AND json_extract(data,'$.imageUrl')=? LIMIT 1").bind('/api/images/'+key).first();
 if(!visible&&!await session(request,env))throw new HttpError(404,'사진을 찾을 수 없습니다.');
 const row=await env.DB.prepare('SELECT bytes,content_type FROM archive_images WHERE id=?').bind(key).first();if(!row)throw new HttpError(404,'사진을 찾을 수 없습니다.');
 return new Response(new Uint8Array(row.bytes),{headers:{'Content-Type':row.content_type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export function importImages(input){
 if(input===undefined)return [];
 if(!Array.isArray(input)||input.length>100)throw new HttpError(400,'사진 목록을 확인해 주세요.');
 const seen=new Set();return input.map(x=>{const key=id(x?.id);if(seen.has(key))throw new HttpError(400,'사진 ID가 중복되었습니다.');seen.add(key);
 if(typeof x.data!=='string'||x.data.length>1333336||!/^[A-Za-z0-9+/]*={0,2}$/.test(x.data))throw new HttpError(400,'사진 백업 형식이 잘못되었습니다.');
 let bytes;try{bytes=Uint8Array.from(atob(x.data),c=>c.charCodeAt(0));}catch{throw new HttpError(400,'사진 백업을 읽지 못했습니다.');}
 if(bytes.length>MAX_IMAGE_BYTES)throw new HttpError(413,'백업 사진이 1MB를 초과합니다.');return {id:key,mime:imageType(bytes),bytes};});
}
