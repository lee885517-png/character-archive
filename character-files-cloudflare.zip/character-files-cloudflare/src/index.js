import {HttpError,defaultSettings,seriesInput,characterInput,settingsInput,importInput,id} from './model.js';
import {uploadImage,serveImage,importImages} from './images.js';
import {login,session,requireSession,readJSON,cookie} from './auth.js';
import adminPage from './admin.html';
import loginPage from './login.html';
import adminJS from './admin-code.txt';
const json=(data,status=200,extra={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json;charset=utf-8','Cache-Control':'no-store',...extra}});
const html=(text)=>new Response(text,{headers:{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow'}});
const readCharacter=r=>({...JSON.parse(r.data),revision:r.revision,updatedAt:r.updated_at});
async function settings(env){const v=await env.DB.prepare('SELECT data FROM archive_settings WHERE id=1').first();return v?{...defaultSettings,...JSON.parse(v.data)}:defaultSettings;}
async function catalog(env,admin=false){
 const [ss,cc,config]=await Promise.all([
 env.DB.prepare('SELECT * FROM archive_series ORDER BY sort_order,name').all(),
 env.DB.prepare(admin?'SELECT * FROM archive_characters ORDER BY updated_at DESC':"SELECT * FROM archive_characters WHERE status='published' ORDER BY updated_at DESC").all(),settings(env)]);
 return {series:ss.results.map(s=>({id:s.id,name:s.name,description:s.description,theme:s.theme,genre:s.genre,sortOrder:s.sort_order,revision:s.revision})),characters:cc.results.map(r=>{const c=readCharacter(r);if(admin)return c;const {sections,...meta}=c;return {...meta,charCount:sections.reduce((n,s)=>n+s.content.length,0),sectionCount:sections.length};}),settings:config};
}
async function manage(request,env){
 const who=await requireSession(request,env,request.method!=='GET');
 if(request.method==='GET')return json(await catalog(env,true));
 if(request.method!=='POST')throw new HttpError(405,'지원하지 않는 요청입니다.');
 const body=await readJSON(request),now=new Date().toISOString();
 switch(body.action){
  case 'saveSeries':{
   const s=seriesInput(body.data),existing=await env.DB.prepare('SELECT revision FROM archive_series WHERE id=?').bind(s.id).first();
   if(existing){if(existing.revision!==s.revision)throw new HttpError(409,'시리즈가 다른 창에서 수정되었습니다. 다시 불러와 주세요.');const r=await env.DB.prepare('UPDATE archive_series SET name=?,description=?,theme=?,genre=?,sort_order=?,revision=revision+1 WHERE id=? AND revision=?').bind(s.name,s.description,s.theme,s.genre,s.sortOrder,s.id,s.revision).run();if(!r.meta.changes)throw new HttpError(409,'동시에 수정되었습니다. 다시 불러와 주세요.');}
   else await env.DB.prepare('INSERT INTO archive_series(id,name,description,theme,genre,sort_order) VALUES (?,?,?,?,?,?)').bind(s.id,s.name,s.description,s.theme,s.genre,s.sortOrder).run();break;
  }
  case 'saveCharacter':{
   const c=characterInput(body.data);if(!await env.DB.prepare('SELECT id FROM archive_series WHERE id=?').bind(c.seriesId).first())throw new HttpError(400,'먼저 소속 시리즈를 만들어 주세요.');
   const old=await env.DB.prepare('SELECT revision FROM archive_characters WHERE id=?').bind(c.id).first();
   if(old){if(old.revision!==c.revision)throw new HttpError(409,'캐릭터가 다른 창에서 수정되었습니다. 다시 불러와 주세요.');const r=await env.DB.prepare('UPDATE archive_characters SET series_id=?,status=?,data=?,revision=revision+1,updated_at=? WHERE id=? AND revision=?').bind(c.seriesId,c.status,JSON.stringify(c),now,c.id,c.revision).run();if(!r.meta.changes)throw new HttpError(409,'동시에 수정되었습니다. 다시 불러와 주세요.');}
   else await env.DB.prepare('INSERT INTO archive_characters(id,series_id,status,data,updated_at) VALUES (?,?,?,?,?)').bind(c.id,c.seriesId,c.status,JSON.stringify(c),now).run();break;
  }
  case 'deleteCharacter':await env.DB.prepare('DELETE FROM archive_characters WHERE id=?').bind(id(body.id)).run();break;
  case 'deleteSeries':{
   const key=id(body.id);if(await env.DB.prepare('SELECT id FROM archive_characters WHERE series_id=? LIMIT 1').bind(key).first())throw new HttpError(409,'소속 캐릭터를 먼저 이동하거나 삭제해 주세요.');await env.DB.prepare('DELETE FROM archive_series WHERE id=?').bind(key).run();break;
  }
  case 'settings':{const s=settingsInput(body.data);await env.DB.prepare('INSERT INTO archive_settings(id,data) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind(JSON.stringify(s)).run();break;}
  case 'import':{
   const images=importImages(body.data?.images),data=importInput(body.data),old=await catalog(env,true),sids=new Set(old.series.map(s=>s.id)),cids=new Set(old.characters.map(c=>c.id)),allS=new Set([...sids,...data.series.map(s=>s.id)]);
   if(data.characters.some(c=>!allS.has(c.seriesId)))throw new HttpError(400,'존재하지 않는 시리즈를 참조하는 캐릭터가 있습니다.');
   const ss=data.series.filter(s=>!sids.has(s.id)),cc=data.characters.filter(c=>!cids.has(c.id));
   const stmts=[...images.map(img=>env.DB.prepare('INSERT OR IGNORE INTO archive_images(id,content_type,bytes,created_at) VALUES (?,?,?,?)').bind(img.id,img.mime,img.bytes.buffer,now)),...ss.map(s=>env.DB.prepare('INSERT OR IGNORE INTO archive_series(id,name,description,theme,genre,sort_order) VALUES (?,?,?,?,?,?)').bind(s.id,s.name,s.description,s.theme,s.genre,s.sortOrder)),...cc.map(c=>env.DB.prepare('INSERT OR IGNORE INTO archive_characters(id,series_id,status,data,updated_at) VALUES (?,?,?,?,?)').bind(c.id,c.seriesId,c.status,JSON.stringify(c),now))];if(body.applySettings){const config=settingsInput(body.data.settings);stmts.push(env.DB.prepare('INSERT INTO archive_settings(id,data) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').bind(JSON.stringify(config)));}if(stmts.length)await env.DB.batch(stmts);
   return json({ok:true,addedSeries:ss.length,addedCharacters:cc.length,skipped:data.series.length+data.characters.length-ss.length-cc.length});
  }
  case 'logout':await env.DB.prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(who.token_hash).run();return json({ok:true},200,{'Set-Cookie':cookie(request,'',0)});
  default:throw new HttpError(400,'지원하지 않는 작업입니다.');
 }return json({ok:true});
}
function protect(response){const r=new Response(response.body,response);r.headers.set('X-Content-Type-Options','nosniff');r.headers.set('Referrer-Policy','no-referrer');r.headers.set('X-Frame-Options','DENY');r.headers.set('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' https: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");return r;}
export default {async fetch(request,env,ctx){try{
 const url=new URL(request.url),path=url.pathname;
 if(path==='/api/admin/images'&&request.method==='POST')return protect(json(await uploadImage(request,env,ctx)));
 if(path.startsWith('/api/images/')&&request.method==='GET')return protect(await serveImage(request,env,path.slice(12)));
 if(path==='/api/catalog'&&request.method==='GET')return protect(json(await catalog(env)));
 if(path.startsWith('/api/characters/')&&request.method==='GET'){const key=id(decodeURIComponent(path.slice(16)));const r=await env.DB.prepare("SELECT * FROM archive_characters WHERE id=? AND status='published'").bind(key).first();if(!r)throw new HttpError(404,'공개된 캐릭터를 찾을 수 없습니다.');return protect(json(readCharacter(r)));}
 if(path==='/api/admin/login'&&request.method==='POST'){const s=await login(request,env,ctx);return protect(json({ok:true,csrf:s.csrf},200,{'Set-Cookie':s.cookie}));}
 if(path==='/api/admin/session'&&request.method==='GET'){const s=await requireSession(request,env);return protect(json({ok:true,csrf:s.csrf}));}
 if(path==='/api/admin/manage')return protect(await manage(request,env));
 if(path==='/api/admin/interface.js'&&request.method==='GET'){await requireSession(request,env);return protect(new Response(adminJS,{headers:{'Content-Type':'text/javascript;charset=utf-8','Cache-Control':'no-store'}}));}
 if(path==='/keeper'||path==='/keeper/'){if(request.method!=='GET')throw new HttpError(405,'지원하지 않는 요청입니다.');return protect(html(await session(request,env)?adminPage:loginPage));}
 if(path.startsWith('/api/')||path.startsWith('/keeper/'))throw new HttpError(404,'페이지를 찾을 수 없습니다.');
 if(!['GET','HEAD'].includes(request.method))throw new HttpError(405,'지원하지 않는 요청입니다.');
 return protect(await env.ASSETS.fetch(request));
 }catch(e){if(e instanceof HttpError)return protect(json({error:e.message},e.status));console.error('Archive request failed',e instanceof Error?e.message:'unknown');return protect(json({error:'저장소에 연결하지 못했습니다. D1 초기 설정을 확인해 주세요.'},500));}}};
