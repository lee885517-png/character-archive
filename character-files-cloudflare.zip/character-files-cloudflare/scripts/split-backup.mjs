import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
const input=process.argv[2],destination=resolve(process.argv[3]||'split-backup');
if(!input){console.error('사용법: node scripts/split-backup.mjs 백업파일.json [출력폴더]');process.exit(1);}
const data=JSON.parse(await readFile(input,'utf8'));const characters=data.characters??data.workshops;
if(![1,2].includes(data.schemaVersion)||!Array.isArray(data.series)||!Array.isArray(characters))throw Error('지원하지 않는 백업 형식입니다.');
await mkdir(destination,{recursive:true});let index=1;const encode=(ss,cc,images=[])=>JSON.stringify({schemaVersion:2,series:ss,characters:cc,images,...(data.settings?{settings:data.settings}:{})},null,2);
async function save(ss,cc,images=[]){const output=encode(ss,cc,images);if(Buffer.byteLength(output)>2000000)throw Error('단일 인물이 2MB를 초과합니다. 본문을 줄이거나 나누어 주세요.');const name=`part-${String(index++).padStart(3,'0')}.json`;await writeFile(resolve(destination,name),output);console.log(name);}
for(const img of data.images||[])await save([],[],[img]);
for(let i=0;i<data.series.length;i+=100)await save(data.series.slice(i,i+100),[]);
let chunk=[];for(const c of characters){if(chunk.length&&(chunk.length>=200||Buffer.byteLength(encode([],chunk.concat(c)))>1950000)){await save([],chunk);chunk=[];}chunk.push(c);}if(chunk.length)await save([],chunk);
console.log('번호 순서대로 가져오세요. 먼저 사진, 다음으로 시리즈와 인물을 추가합니다.');
