import {createInterface} from 'node:readline/promises';
import {Writable} from 'node:stream';
import {pbkdf2Sync,randomBytes} from 'node:crypto';
import {readFile,writeFile,chmod} from 'node:fs/promises';
import {spawn} from 'node:child_process';
if(!process.stdin.isTTY){console.error('터미널에서 직접 실행해 주세요. 비밀번호를 명령어 인수로 넣지 마세요.');process.exit(1);}
const mode=process.argv[2];if(!['--local','--remote'].includes(mode)){console.error('npm run password:local 또는 npm run password:remote로 실행해 주세요.');process.exit(1);}
const sink=new Writable({write(_chunk,_encoding,callback){callback();}});sink.isTTY=true;sink.columns=process.stdout.columns||80;
const rl=createInterface({input:process.stdin,output:sink,terminal:true});
rl.on('SIGINT',()=>{rl.close();process.stdout.write('\n취소했습니다.\n');process.exit(130)});
async function ask(q){process.stdout.write(q);const s=await rl.question('');process.stdout.write('\n');return s;}
console.log(mode==='--remote'?'Cloudflare 관리자 비밀번호 설정':'내 컴퓨터의 개발용 비밀번호 설정');
console.log('16~256자 비밀번호를 입력하세요. 입력 내용은 화면에 표시되지 않습니다.');
const a=await ask('새 비밀번호: ');const b=await ask('한 번 더 입력: ');rl.close();
if(a!==b){console.error('두 비밀번호가 일치하지 않습니다. 다시 실행해 주세요.');process.exit(1);}
if(a.length<16||a.length>256){console.error('비밀번호는 16~256자로 정해 주세요.');process.exit(1);}
const salt=randomBytes(16);const hash=`pbkdf2:100000:${salt.toString('hex')}:${pbkdf2Sync(a,salt,100000,32,'sha256').toString('hex')}`;
if(mode==='--local'){
 let previous='';try{previous=await readFile('.dev.vars','utf8')}catch(e){if(e.code!=='ENOENT')throw e;}
 const cleaned=previous.split('\n').filter(l=>!/^\s*ADMIN_PASSWORD_HASH\s*=/.test(l)).join('\n').trim();
 await writeFile('.dev.vars',(cleaned?cleaned+'\n':'')+'ADMIN_PASSWORD_HASH='+JSON.stringify(hash)+'\n',{mode:0o600});await chmod('.dev.vars',0o600);
 console.log('개발용 비밀번호를 설정했습니다. 개발 서버가 실행 중이라면 다시 시작해 주세요.');
}else{
 const p=spawn(process.execPath,['node_modules/wrangler/bin/wrangler.js','secret','bulk'],{stdio:['pipe','inherit','inherit']});
 p.stdin.end(JSON.stringify({ADMIN_PASSWORD_HASH:hash}));
 const code=await new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',resolve)});
 if(code!==0)process.exit(code||1);
 console.log('관리자 비밀번호를 설정했습니다. 기존 로그인 세션은 무효화됩니다.');
}
