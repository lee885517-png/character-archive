import {readFile,writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
const path='wrangler.jsonc',config=JSON.parse(await readFile(path,'utf8'));
const db=config.d1_databases.find(x=>x.binding==='DB');
if(db.database_id!=='00000000-0000-4000-8000-000000000000'){console.log('DB 연결 ID가 이미 설정되어 있습니다. 다음으로 npm run db:remote를 실행하세요.');process.exit(0);}
console.log(`${db.database_name} 데이터베이스를 만듭니다. Cloudflare 로그인을 먼저 완료해 주세요.`);
const p=spawn(process.execPath,['node_modules/wrangler/bin/wrangler.js','d1','create',db.database_name,'--update-config=false'],{stdio:['inherit','pipe','inherit']});
let output='';p.stdout.on('data',chunk=>{output+=chunk;process.stdout.write(chunk)});
const code=await new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',resolve)});if(code!==0)process.exit(code||1);
const match=output.match(/["']?database_id["']?\s*[:=]\s*["']([a-f0-9-]{36})["']/i);
if(!match){console.error('DB는 생성되었지만 ID를 자동으로 읽지 못했습니다. 위 database_id 값을 wrangler.jsonc의 DB 항목에 붙여 넣어 주세요.');process.exit(1);}
db.database_id=match[1];await writeFile(path,JSON.stringify(config,null,2)+'\n');console.log('wrangler.jsonc에 DB 연결을 저장했습니다. 다음: npm run db:remote');
