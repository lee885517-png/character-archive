import {spawn} from 'node:child_process';
const args=process.argv.slice(2).filter(x=>x!=='--strictPort').map(x=>x==='--host'?'--ip':x);
const p=spawn(process.execPath,['node_modules/wrangler/bin/wrangler.js','dev',...args],{stdio:'inherit'});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>p.kill(signal));
p.on('exit',code=>process.exit(code??0));p.on('error',e=>{console.error(e.message);process.exit(1)});
