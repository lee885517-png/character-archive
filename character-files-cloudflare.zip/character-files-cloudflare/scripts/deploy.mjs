import {readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
const config=JSON.parse(await readFile('wrangler.jsonc','utf8'));
const db=config.d1_databases?.find(x=>x.binding==='DB');
if(!db||db.database_id==='00000000-0000-4000-8000-000000000000'){
 console.error('D1 데이터베이스 ID가 아직 없습니다. npm run db:create 실행 후 wrangler.jsonc의 DB 바인딩을 확인해 주세요.');process.exit(1);
}
const r=spawnSync(process.execPath,['node_modules/wrangler/bin/wrangler.js','deploy',...process.argv.slice(2)],{stdio:'inherit'});process.exit(r.status??1);
