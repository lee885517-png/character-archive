import {build} from 'esbuild';
import {mkdir,cp} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await build({entryPoints:['src/index.js'],outfile:'dist/worker.mjs',bundle:true,format:'esm',platform:'neutral',target:'es2022',loader:{'.html':'text','.txt':'text'}});
await cp('public','dist/public',{recursive:true});
console.log('Built Worker and public assets.');
