export const $=(s,root=document)=>root.querySelector(s);
export const $$=(s,root=document)=>Array.from(root.querySelectorAll(s));
export const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function toast(message){const el=$('#toast');const host=$('dialog[open]')||document.body;if(el.parentElement!==host)host.append(el);el.textContent=message;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>{el.hidden=true},3600);}
export async function api(path,options={}){let r;try{r=await fetch(path,{credentials:'same-origin',...options});}catch{throw Error('연결이 끊겼습니다. 인터넷 연결을 확인해 주세요.');}const data=await r.json().catch(()=>({error:'사이트에 연결하지 못했습니다.'}));if(!r.ok){const e=Error(data.error||'요청을 처리하지 못했습니다.');e.status=r.status;throw e;}return data;}
export async function copyText(text){try{await navigator.clipboard.writeText(text);}catch{const area=document.createElement('textarea');area.value=text;area.className='copy-buffer';($('dialog[open]')||document.body).append(area);area.select();let ok=false;try{ok=document.execCommand('copy')}finally{area.remove()}if(!ok)throw Error('자동 복사가 차단되었습니다. 설정 본문을 선택해 복사해 주세요.');}toast('설정을 복사했습니다.');}
export function download(text,name,type='text/plain;charset=utf-8'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
export const fileName=s=>s.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').slice(0,90)||'character';
export const dateLabel=s=>s?new Intl.DateTimeFormat('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Seoul'}).format(new Date(s)):'';
export const rawText=c=>c.sections.map(s=>s.content).join('\n\n');
export function initials(s){return Array.from(s.trim()).slice(0,1).join('')||'書';}
export function handleImages(root=document){$$('img[data-portrait]',root).forEach(img=>{img.addEventListener('error',()=>{img.hidden=true;img.closest('.portrait').classList.add('image-failed')},{once:true});});}
export const theme=s=>['wine','forest','navy','umber'].includes(s)?s:({violet:'wine',blue:'navy',mint:'forest',rose:'wine',amber:'umber',slate:'navy'}[s]||'wine');
