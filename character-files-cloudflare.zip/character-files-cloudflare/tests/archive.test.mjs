import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {pbkdf2Sync} from 'node:crypto';
import {Miniflare} from 'miniflare';
import {characterInput,imageURL,rawText} from '../src/model.js';
const origin='https://archive.example';
const password='Test-only-long-password-2026!';
const salt='0123456789abcdef0123456789abcdef';
const passwordHash=`pbkdf2:100000:${salt}:${pbkdf2Sync(password,Buffer.from(salt,'hex'),100000,32,'sha256').toString('hex')}`;
let mf,db,authCookie='',csrf='';
const options={modules:true,scriptPath:'dist/worker.mjs',compatibilityDate:'2026-05-15',d1Databases:['DB'],bindings:{ADMIN_PASSWORD_HASH:passwordHash},serviceBindings:{ASSETS:()=>new Response('public asset')}};
const request=(path,init={})=>mf.dispatchFetch(origin+path,init);
const write=(body,headers={})=>request('/api/admin/manage',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',Cookie:authCookie,'X-Seoga-CSRF':csrf,...headers},body:JSON.stringify(body)});
const login=(pw=password,ip='192.0.2.1',extra={})=>request('/api/admin/login',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json','CF-Connecting-IP':ip,...extra},body:JSON.stringify({password:pw})});
const c={id:'test-character',seriesId:'test-series',title:'기록자',summary:'테스트 인물',profile:{role:'조사관',species:'인간',age:'성인',gender:'남성'},category:'캐릭터',tags:['시험'],version:'1.0',status:'draft',sections:[{id:'profile',title:'소개',language:'html',content:'  첫 줄\n<script>alert("test")</script>\n끝  '}],sortOrder:0};
before(async()=>{mf=new Miniflare(options);db=await mf.getD1Database('DB');for(const file of (await readdir('migrations')).filter(x=>x.endsWith('.sql')).sort())await db.exec((await readFile('migrations/'+file,'utf8')).replace(/\n/g,' '));});
after(async()=>{await mf?.dispose()});
test('server authentication, publication and ownership boundaries',async t=>{
 await t.test('private management and interface reject anonymous access',async()=>{
  for(const p of ['/api/admin/manage','/api/admin/session','/api/admin/interface.js'])assert.equal((await request(p)).status,401,p);
  const page=await request('/keeper');assert.equal(page.status,200);assert.match(await page.text(),/login-form/);assert.match(page.headers.get('Cache-Control'),/no-store/);
  assert.equal((await write({action:'saveCharacter',data:c})).status,401);
 });
 await t.test('login requires same origin and correct password',async()=>{
  assert.equal((await login(password,'192.0.2.1',{Origin:'https://elsewhere.example'})).status,403);
  assert.equal((await login('incorrect')).status,401);
  const r=await login();assert.equal(r.status,200);authCookie=r.headers.get('set-cookie').split(';')[0];csrf=(await r.json()).csrf;assert.match(r.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);assert.match(r.headers.get('set-cookie'),/Secure/);assert.match(authCookie,/^__Host-seoga_admin=/);
  const script=await request('/api/admin/interface.js',{headers:{Cookie:authCookie}});assert.equal(script.status,200);assert.match(await script.text(),/saveCharacter/);
  const page=await request('/keeper',{headers:{Cookie:authCookie}});assert.match(await page.text(),/editor-form/);
 });
 await t.test('mutations need both origin and csrf',async()=>{
  assert.equal((await write({action:'saveSeries',data:{id:'test-series',name:'시리즈'}},{'X-Seoga-CSRF':''})).status,403);
  assert.equal((await write({action:'saveSeries',data:{id:'test-series',name:'시리즈'}},{Origin:'https://evil.example'})).status,403);
  assert.equal((await write({action:'saveSeries',data:{id:'test-series',name:'시리즈',genre:'urban'}})).status,200);
 });
 await t.test('photo uploads require authentication and valid image data',async()=>{
  const bytes=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/h1cAAAAASUVORK5CYII=','base64');
  const upload=(body,headers={})=>request('/api/admin/images',{method:'POST',headers:{Origin:origin,'Content-Type':'image/png',Cookie:authCookie,'X-Seoga-CSRF':csrf,...headers},body});
  assert.equal((await upload(bytes,{Cookie:''})).status,401);
  assert.equal((await upload(bytes,{'X-Seoga-CSRF':''})).status,403);
  assert.equal((await upload(bytes,{Origin:'https://elsewhere.example'})).status,403);
  assert.equal((await upload('<svg onload="alert(1)"></svg>')).status,400);
  assert.equal((await upload(new Uint8Array(1000001))).status,413);
  const r=await upload(bytes);assert.equal(r.status,200);c.imageUrl=(await r.json()).url;
  assert.equal((await request(c.imageUrl)).status,404);
  const own=await request(c.imageUrl,{headers:{Cookie:authCookie}});assert.equal(own.status,200);assert.equal(own.headers.get('Content-Type'),'image/png');assert.deepEqual(Buffer.from(await own.arrayBuffer()),bytes);
 });
 await t.test('drafts never appear in public catalog or direct detail',async()=>{
  assert.equal((await write({action:'saveCharacter',data:c})).status,200);
  const cat=await (await request('/api/catalog')).json();assert.equal(cat.characters.length,0);assert.equal(cat.series[0].genre,'urban');assert.equal((await request(c.imageUrl)).status,404);
  assert.equal((await request('/api/characters/test-character')).status,404);
  const admin=await (await request('/api/admin/manage',{headers:{Cookie:authCookie}})).json();assert.equal(admin.characters.length,1);assert.equal(admin.characters[0].sections[0].content,c.sections[0].content);
 });
 await t.test('publish preserves raw text; metadata endpoint omits bodies',async()=>{
  assert.equal((await write({action:'saveCharacter',data:{...c,revision:1,status:'published'}})).status,200);
  const cat=await (await request('/api/catalog')).json();assert.equal(cat.characters.length,1);assert.equal('sections'in cat.characters[0],false);
  const detail=await (await request('/api/characters/test-character')).json();assert.equal(detail.sections[0].content,c.sections[0].content);assert.equal(detail.revision,2);assert.equal(detail.profile.role,'조사관');assert.equal((await request(c.imageUrl)).status,200);
 });
 await t.test('stale edits and removal of an occupied series are blocked',async()=>{
  assert.equal((await write({action:'saveCharacter',data:{...c,revision:1,title:'덮어쓰기'}})).status,409);
  assert.equal((await write({action:'deleteSeries',id:'test-series'})).status,409);
 });
 await t.test('invalid category, image and dangling references are rejected',async()=>{
  for(const bad of [{...c,id:'bad1',category:'세계관'},{...c,id:'bad2',imageUrl:'javascript:alert(1)'},{...c,id:'bad3',seriesId:'missing'}])assert.equal((await write({action:'saveCharacter',data:bad})).status,400);
 });
 await t.test('old backup imports atomically and skips existing IDs',async()=>{
  const old={schemaVersion:1,series:[{id:'new-series',name:'이전 기록'}],workshops:[{...c,id:'imported',seriesId:'new-series'}]};
  const r=await write({action:'import',data:old});assert.equal(r.status,200);assert.equal((await r.json()).addedCharacters,1);
  const repeated=await (await write({action:'import',data:old})).json();assert.equal(repeated.addedCharacters,0);assert.equal(repeated.skipped,2);
  const failed=await write({action:'import',data:{schemaVersion:1,series:[{id:'not-committed',name:'롤백'}],characters:[{...c,id:'bad-import',seriesId:'missing'}]}});assert.equal(failed.status,400);
  assert.equal(await db.prepare("SELECT id FROM archive_series WHERE id='not-committed'").first(),null);
 });
 await t.test('version 2 backups restore images and category; unpublishing hides uploaded photos',async()=>{
  const encoded='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/h1cAAAAASUVORK5CYII=';
  const backup={schemaVersion:2,images:[{id:'restored-photo',data:encoded}],series:[{id:'restored-series',name:'복구 시리즈',genre:'fantasy'}],characters:[{...c,id:'restored-character',seriesId:'restored-series',imageUrl:'/api/images/restored-photo',status:'published'}]};
  assert.equal((await write({action:'import',data:backup})).status,200);assert.equal((await request('/api/images/restored-photo')).status,200);
  assert.equal((await write({action:'saveCharacter',data:{...c,revision:2,status:'draft'}})).status,200);assert.equal((await request(c.imageUrl)).status,404);
  assert.equal((await write({action:'saveSeries',data:{id:'invalid-genre',name:'오류',genre:'other'}})).status,400);
 });
 await t.test('sixth wrong login is throttled; other IP remains usable',async()=>{
  for(let i=0;i<5;i++)assert.equal((await login('wrong','192.0.2.44')).status,401);
  assert.equal((await login('wrong','192.0.2.44')).status,429);
  assert.equal((await login(password,'192.0.2.45')).status,200);
 });
 await t.test('logout revokes session and tampered cookies fail',async()=>{
  assert.equal((await write({action:'logout'})).status,200);
  assert.equal((await request('/api/admin/manage',{headers:{Cookie:authCookie}})).status,401);
  assert.equal((await request('/api/admin/manage',{headers:{Cookie:'__Host-seoga_admin='+'a'.repeat(64)}})).status,401);
 });
 await t.test('expired and password-rotated sessions fail',async()=>{
  const r=await login();const cookie=r.headers.get('set-cookie').split(';')[0];await db.prepare('UPDATE admin_sessions SET expires_at=0').run();assert.equal((await request('/api/admin/manage',{headers:{Cookie:cookie}})).status,401);
  const fresh=await login();const cookie2=fresh.headers.get('set-cookie').split(';')[0];await db.prepare("UPDATE admin_sessions SET password_version='outdated'").run();assert.equal((await request('/api/admin/manage',{headers:{Cookie:cookie2}})).status,401);
 });
 await t.test('unconfigured deployments stay locked',async()=>{
  await mf.setOptions({...options,bindings:{}});assert.equal((await login()).status,503);assert.equal((await request('/api/admin/manage')).status,401);
 });
});
test('profile copy is lossless and unsafe images are rejected',()=>{
 assert.equal(rawText(characterInput(c)),c.sections[0].content);
 for(const value of ['javascript:alert(1)','data:image/svg+xml,test','http://unsafe.example/p.png','//example.com/a.png','/api/admin/session'])assert.throws(()=>imageURL(value));
 assert.equal(imageURL('/portraits/name.webp'),'/portraits/name.webp');assert.equal(imageURL('https://example.com/image.webp'),'https://example.com/image.webp');
});
test('public entry has no owner navigation or secrets',async()=>{
 const html=await readFile('public/index.html','utf8');assert.doesNotMatch(html,/keeper|ADMIN_PASSWORD_HASH|api\/admin/);
 const source=await readFile('public/app.js','utf8');assert.doesNotMatch(source,/keeper|api\/admin/);
});
