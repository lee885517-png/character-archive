CREATE TABLE archive_series (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  theme TEXT NOT NULL DEFAULT 'wine',
  sort_order INTEGER NOT NULL DEFAULT 0,
  revision INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE archive_characters (
  id TEXT PRIMARY KEY,
  series_id TEXT NOT NULL REFERENCES archive_series(id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published')),
  data TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);
CREATE INDEX characters_by_series ON archive_characters(series_id, status);
CREATE TABLE archive_settings (id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL);
CREATE TABLE admin_sessions (
  token_hash TEXT PRIMARY KEY,
  csrf TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  password_version TEXT NOT NULL
);
CREATE INDEX sessions_expiry ON admin_sessions(expires_at);
CREATE TABLE login_attempts (
  key TEXT PRIMARY KEY,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NOT NULL
);
