ALTER TABLE archive_series ADD COLUMN genre TEXT NOT NULL DEFAULT 'special';
CREATE INDEX series_by_genre ON archive_series(genre, sort_order);
CREATE TABLE archive_images (
  id TEXT PRIMARY KEY,
  content_type TEXT NOT NULL,
  bytes BLOB NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX characters_by_image ON archive_characters(json_extract(data, '$.imageUrl'), status);
